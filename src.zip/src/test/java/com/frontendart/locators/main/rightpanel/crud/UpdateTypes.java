package com.frontendart.locators.main.rightpanel.crud;

/**
 * Record update types
 * @author Zoli
 *
 */
public enum UpdateTypes {
	FORM,
	INLINE
}
