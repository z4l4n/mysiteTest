package com.frontendart.managers.main.leftpanel;

/**
 * Enum class for validate search types
 * 
 * @author Zoli
 *
 */
public enum SearchCheckTypes {
	IS_EVERY_IS_MET,
	IS_EVERY_IS_NOT_MET,
	IS_ANY_IS_MET,
	IS_ANY_IS_NOT_MET;
}
